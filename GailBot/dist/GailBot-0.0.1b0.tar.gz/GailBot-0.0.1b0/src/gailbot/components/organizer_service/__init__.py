# -*- coding: utf-8 -*-
# @Author: Muhammad Umair
# @Date:   2021-12-02 13:40:20
# @Last Modified by:   Muhammad Umair
# @Last Modified time: 2021-12-02 13:40:25
from .organizer_service import OrganizerService

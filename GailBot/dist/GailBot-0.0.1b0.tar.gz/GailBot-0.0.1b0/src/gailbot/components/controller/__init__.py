# -*- coding: utf-8 -*-
# @Author: Muhammad Umair
# @Date:   2021-12-02 13:21:39
# @Last Modified by:   Muhammad Umair
# @Last Modified time: 2021-12-02 13:21:47

from .controller import GailBotController
